import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-YHZQG3JS.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-CWEEFEZV.js";
import "./chunk-G5RMHOFD.js";
import "./chunk-WAMAERZZ.js";
import "./chunk-Q2UCJEEB.js";
import "./chunk-W32QAUNZ.js";
import "./chunk-GVXIVFU2.js";
import "./chunk-6ZLSYGRX.js";
import "./chunk-4MWRP73S.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
