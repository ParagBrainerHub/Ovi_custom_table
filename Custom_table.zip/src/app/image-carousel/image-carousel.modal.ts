export interface CarouselButtonsConfig {
  prevIcon: string;
  nextIcon: string;
}
